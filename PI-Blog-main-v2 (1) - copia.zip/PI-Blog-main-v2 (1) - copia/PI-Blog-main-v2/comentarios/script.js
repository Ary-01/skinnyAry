// Función para enviar el comentario
function sendComment(event) {
    event.preventDefault();  // Evita cualquier comportamiento predeterminado (como redirección)
    const comment = document.getElementById("comment").value;
    
    if (comment.trim() !== "") {
        // Crear un nuevo elemento de comentario
        const commentElement = document.createElement("div");
        commentElement.classList.add("comment");
        commentElement.textContent = comment;

        // Agregar el comentario al contenedor de comentarios
        document.getElementById("commentsContainer").appendChild(commentElement);

        // Limpiar el textarea después de enviar
        document.getElementById("comment").value = "";
    }
}

// Función para enviar el comentario al presionar Enter
document.getElementById("comment").addEventListener("keypress", function(event) {
    if (event.key === "Enter" && !event.shiftKey) {
        event.preventDefault(); // Evita el salto de línea
        sendComment(event);
    }
});
