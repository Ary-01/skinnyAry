<?php
// Incluir la conexión a la base de datos
include 'db.php';

// Verificar si se envió un nuevo comentario
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = 1; // Cambia esto por el ID del usuario que está logueado
    $comment = mysqli_real_escape_string($conn, $_POST['comment']);

    // Insertar el comentario en la base de datos
    $query = "INSERT INTO comments (user_id, comment) VALUES ($user_id, '$comment')";
    if (mysqli_query($conn, $query)) {
        echo "Comentario guardado correctamente!";
    } else {
        echo "Error al guardar el comentario: " . mysqli_error($conn);
    }
}

// Mostrar los comentarios
$query = "SELECT comments.comment, users.name FROM comments JOIN users ON comments.user_id = users.id ORDER BY comments.created_at DESC";
$result = mysqli_query($conn, $query);
?>

<h2>Comentarios</h2>
<button type="submit" id="submit-comment" title="Enviar comentario">✈️</button>


<div class="comments">
    <?php
    // Mostrar los comentarios
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<div class='comment'>";
            echo "<p><strong>" . htmlspecialchars($row['name']) . ":</strong> " . htmlspecialchars($row['comment']) . "</p>";
            echo "</div>";
        }
    } else {
        echo "<p>No hay comentarios aún.</p>";
    }
    ?>
</div>
