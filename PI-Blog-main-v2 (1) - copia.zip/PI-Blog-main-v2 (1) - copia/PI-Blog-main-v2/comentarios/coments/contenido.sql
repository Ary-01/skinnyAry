USE coments;
-- Ver el contenido de la tabla users
SELECT * FROM users;

-- Ver el contenido de la tabla comments
SELECT * FROM comments;

