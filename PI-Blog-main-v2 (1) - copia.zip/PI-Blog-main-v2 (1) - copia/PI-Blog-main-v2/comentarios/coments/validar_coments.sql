USE coments;

-- Agregar un usuario
INSERT INTO users (name) VALUES ('Ana');

-- Agregar un comentario de ese usuario
INSERT INTO comments (user_id, comment)
VALUES (1, 'Este es un comentario de Ana');
