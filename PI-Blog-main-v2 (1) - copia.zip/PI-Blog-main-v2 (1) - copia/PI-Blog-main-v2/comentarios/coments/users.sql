-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 28-03-2025 a las 16:48:29
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `db_blog`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(50) DEFAULT 'usuario',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `created_at`) VALUES
(1, 'Prueva', 'JAJAJ@gmail.com', '$2b$10$XcNEKgHD52uP01izHvFMA.tKxcHv/ExMg/vXo0fEg9IolLrDBNhF2', 'usuario', '2025-03-14 06:05:24'),
(2, 'Prueva123', 'tilíncholo@gmail.com', '$2b$10$cKzsnu5FyYGukDA8z7H1IOyqZMjjnJxPX1jxuuW16uLUI80raWPq.', 'usuario', '2025-03-14 06:08:12'),
(3, 'Jahir', 'jespitia@gmal.com', '$2b$10$UNpNvaXRJugADgoge3tu2e0j8kd09YwoD476coJm.zbdElyYJLic6', 'usuario', '2025-03-14 06:16:38'),
(4, 'amo a sahid', 'amorsahid@gmail.com', '$2b$10$Iaeg8BB1LwohXSFJnL7F9uMRCvpGLcvucpCeB98eARezs48PPdKIO', 'usuario', '2025-03-14 13:26:52'),
(6, 'Roxanabanana', 'JSIHSHh@Sgay', '$2b$10$02PPOsBhvAa9NpiJM3cpaujXn7IE0/YEDjIXtYsA/D8mAok40dlve', 'usuario', '2025-03-14 15:14:50'),
(7, 'brandom', 'brandom@gmail.com', '$2b$10$1.vHEAZkPGgHFAa0WxJkkOL7HakcxhVzG7o0e6O1VmNhvvFvhRcSa', 'usuario', '2025-03-14 15:35:17'),
(8, 'Juanito', 'juanbb@gmail.com', '$2b$10$qonr63eVz/CQ9Kcv5cF.luIpyszCIS5ZX0zoz/aHcQx/7L1pgjanG', 'usuario', '2025-03-19 15:39:21'),
(9, 'fjnfjnfj', 'dknfknfn@jeijrji.fm', '$2b$10$6vqJWwNzUW1XYJnEmKuXKerqg7pbQuT8ZLtr32lX.KWLTR7uk/RDi', 'usuario', '2025-03-27 23:13:30'),
(10, 'yoahorita', 'jdjdf@gmail.co', '$2b$10$0snqFz/n/9/Gjb8R9FKTtO0G3Khl4XdY/eno2g.herClIkqfytsDe', 'usuario', '2025-03-28 15:28:15'),
(11, 'Guchi_Gang', 'gsolorzano3@ucol.mx', '$2b$10$Xz02doYevW8ig/zHUmxQquL0e0J2A2iWtob/jtenm0W4qbbldVu4y', 'usuario', '2025-03-28 15:31:48'),
(12, 'efhuefu', 'jidijd@hhffj', '$2b$10$KAlh22qlP4prPOyqEnd.p.p9a39FtDtZtNNmvbASGsFRUqijGDi06', 'usuario', '2025-03-28 15:42:48');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
