<?php
$host = 'localhost'; // Cambia esto si es necesario
$username = 'root'; // El nombre de usuario de MySQL
$password = ''; // La contraseña de MySQL (si no tienes, déjalo vacío)
$dbname = 'coments'; // El nombre de la base de datos

// Crear la conexión
$conn = new mysqli($host, $username, $password, $dbname);

// Verificar si hubo un error de conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
